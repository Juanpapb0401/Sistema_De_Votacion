package sistemaVotacion;

import com.zeroc.Ice.Communicator;
import com.zeroc.Ice.Util;
import Controller;

public class SistemaVotacion {
    public static void main(String[] args) throws Exception {
        // Initialize the Ice communicator
        Communicator communicator = Util.initialize(args);
        
        try {
            // Create and start our controller
            Controller controller = new Controller();
            controller.startUI();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Clean shutdown
            if (communicator != null) {
                communicator.destroy();
            }
        }
    }
} 