package sistemaVotacion;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Controller {
    
    private List<String> candidates;

    public Controller() {
        this.candidates = new ArrayList<>();
    }

    public static void main(String[] args)throws Exception {
        Communicator com = Util.initialize();
        RMSourcePrx rm = RMSourcePrx.checkedCast(com.stringToProxy("Sender:tcp -h localhost -p 10010"));
        RMDestinationPrx dest = RMDestinationPrx.uncheckedCast(com.stringToProxy("Service:tcp -h localhost -p 10012"));
        Controller controller = new Controller();
        controller.startUI();

        rm.setServerProxy(dest);
        Message msg = new Message();
        for (int i = 0; i < 10; i++) {
            msg.message = "Send with RM "+i;
            rm.sendMessage(msg);
            System.out.println("sended "+i);
            Thread.sleep(5000);
        }
        com.shutdown();
        
    }

    public void startUI() throws FileNotFoundException{
        System.out.println("Bienvenido al sistema de votacion");
        System.out.println("1. Iniciar votacion");
        System.out.println("2. Salir");
        int option = Integer.parseInt(System.console().readLine());
        switch(option) {
            case 1:
                startVotation();
                break;
            case 2:
                System.out.println("Saliendo del sistema");
                break;
        }
    }

    public void startVotation() throws FileNotFoundException {
        System.out.println("Estos son los candidatos disponibles: ");
        readCandidates();
        for (int i = 0; i < candidates.size(); i++) {
            System.out.println(i + ". " + candidates.get(i));
        }
        System.out.println("Ingrese el numero del candidato que desea votar: ");
        int candidateNumber = Integer.parseInt(System.console().readLine());
    }

    public void readCandidates() throws FileNotFoundException{
        File file = new File("Candidatos.txt");
        try {
            Scanner scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                candidates.add(line);
            }
            scanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo Candidatos.txt");
            e.printStackTrace();
        }
    }
}
