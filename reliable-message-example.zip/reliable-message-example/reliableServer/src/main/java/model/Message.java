package model;

import java.io.Serializable;

public class Message implements Serializable {
    
    public String message;
}
